"""
Module for management tasks common to Infoxchange django applications.

.. moduleauthor:: Infoxchange Development Team <development@infoxchange.net.au>

"""
