"""
Module for management commands (command-line tools) for the
IX Login application

.. moduleauthor:: Infoxchange Development Team <development@infoxchange.net.au>

"""
