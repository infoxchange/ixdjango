"""
Client application for providing functionality common to Infoxchange django
applications.

.. moduleauthor:: Infoxchange Development Team <development@infoxchange.net.au>

"""
